document.addEventListener('DOMContentLoaded',function(){
    // document.getElementById('FAQ').style.backgroundColor = 'red';
    let FAQ = document.getElementById('FAQ').children;
    console.log(FAQ);

    for(let i=0; i<FAQ.length; i++){
        if(FAQ[i].tagName == 'DT'){
            FAQ[i].style.backgroundColor = 'green'; 
            FAQ[i].style.textTransform = 'uppercase';
        }
    }

    for(let i=0; i<FAQ.length; i++){
        if(FAQ[i].tagName == 'DT'){
            FAQ[i].addEventListener('click',function(){
                let DD = FAQ[i].nextElementSibling;
                DD.classList.toggle('hidden')
            });
        }
    }

    let mobileMenu = document.getElementById('toggle-icon')
    mobileMenu.addEventListener('click',function(){
        let menubox = document.getElementById('menu-box')
        // menubox.style.display = 'block';
        menubox.classList.toggle('hidden');
    })
    
});