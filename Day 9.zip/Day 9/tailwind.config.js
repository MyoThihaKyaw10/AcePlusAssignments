/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./public/**/*.{html,js}"],
  theme: {
    fontFamily : {
      "logofont" : "var(--logofont)",
      "titlefont" : "var(--titlefont)",
      "textfont" : "var(--textfont)"
    },
    colors: {
      black : "var(--black)",
      white : "var(--white)",
      orange : "var(--orange)",
      grey : "var(--grey)",
      blue : "var(--blue)",
      red : "var(--red)"
    },
    extend: {
      height: {
        "sidebar" : 'calc(100vh - 68px)'
      }
    },
  },
  plugins: [],
}

