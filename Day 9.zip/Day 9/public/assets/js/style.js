menu = document.querySelector(".hamburger"),
aside = document.getElementById("side-bar"),
main = document.getElementById("main-content");
footer = document.querySelector(".footer");

menu.addEventListener("click",function()
    {
        aside.classList.toggle("w-0");
        aside.classList.toggle("w-1/5");
        main.classList.toggle("w-full");
        main.classList.toggle("w-4/5");
        footer.classList.toggle("w-full");
        footer.classList.toggle("w-4/5");
    }
);

const heading = document.querySelector(".title-box"),
paragraphs = document.querySelectorAll(".paragraph");

let titles = heading.children;

for(let i = 0; i < titles.length ; i++){
    titles[i].addEventListener("click",function(){
        for (let j = 0; j < titles.length; j++){
            titles[j].classList.remove("active");
            paragraphs[j].classList.add("hidden");
        }
        this.classList.add("active");
        paragraphs[i].classList.remove("hidden");
    })
}


// document.querySelectorAll(".accordion-btn").forEach((btn) => {
//   btn.addEventListener("click", () => {
//     const content = btn.nextElementSibling;
//     const icon = btn.querySelector("span");

//     if (content) {
//       content.classList.toggle("hidden");
//     }

//     if (icon) {
//       icon.textContent = icon.textContent === "+" ? "-" : "+";
//     }
//   });
// });

document.addEventListener("DOMContentLoaded", function () {
  const accordionButtons = document.querySelectorAll(".accordion-btn");

  accordionButtons.forEach((btn) => {
    btn.addEventListener("click", () => {
      const content = btn.nextElementSibling;
      const isOpen = !content.classList.contains("hidden");

      // Close all others
      accordionButtons.forEach((otherBtn) => {
        const otherContent = otherBtn.nextElementSibling;
        if (otherContent !== content) {
          otherContent.classList.add("hidden");
          otherBtn.querySelector("span").textContent = "+";
        }
      });

      // Toggle this one
      content.classList.toggle("hidden");
      btn.querySelector("span").textContent = isOpen ? "+" : "-";
    });
  });
});
